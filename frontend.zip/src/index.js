const axios = require("axios");

class App {
    constructor(){
        this.buttonCreate = document.getElementById("btn_create");
        this.buttonEdit = document.getElementById("btn_edit");
        this.buttonLogin = document.getElementById("btn_login");
        this.buttonCadastro = document.getElementById("btn_cadastro");
        this.buttonEfetuarLogin = document.getElementById("btn_Efetuarlogin");
        this.buttonEfetuarCadastro = document.getElementById("btn_EfetuarCadastro");

        this.titleEdit = document.getElementById("edit-title");
        this.contentEdit = document.getElementById("edit-content");

        this.Login = document.getElementById("email-login");
        this.Password = document.getElementById("password-login");
        this.name = document.getElementById("name-cadastro");
        this.email = document.getElementById("email-cadastro");
        this.pass = document.getElementById("password-cadastro");

        this.title = document.getElementById("input_title");
        this.content = document.getElementById("input_content");
        this.url = 'https://cards-with-login-and-auth.herokuapp.com';
        //this.url = 'http://localhost:3333';
        //this.getScraps(this);
        //this.getLogin(this);
        this.registerEvents();
        this.token;
        this.idUser;
    }

    //REGISTRA O EVENTO DOS BUTTONS
    registerEvents() {
        this.buttonCreate.onclick = (event) => this.createCard(event);
        this.buttonLogin.onclick = (event) => this.login(event);
        this.buttonCadastro.onclick = (event) => this.cadastro(event);
        this.buttonEfetuarLogin.onclick = (event) => this.efetuarLogin();
        this.buttonEfetuarCadastro.onclick = (event) => this.efetuarCadastro();
        this.buttonEdit.onclick = (event) => this.editCard(event, document.getElementById("label-id").value);
    }

    efetuarLogin(){
        $('#modalLogin').modal('show');
    }

    efetuarCadastro(){
        $('#modalCadastro').modal('show');
    }

    cadastro(event){
        event.preventDefault();
        const url = this.url + `/users`    
        let data ={
            name: this.name.value,
            email: this.email.value,
            password: this.pass.value
        }
        this.getCadastro(url,data, this);
    }

    login(event){
        event.preventDefault();
        const url = this.url + `/login`    
        let data ={
            email: this.Login.value,
            password: this.Password.value
        }
        this.getLogin(url,data, this);
    }

    getCadastro(url,data,app){
        console.log('teste');
        axios.post(url,data)
        .then(function(response){
            alert('Cadastro efetuado com sucesso');
            $('#modalCadastro').modal('hide');
            this.efetuarLogin();
        })
        .catch(function(error){
            })
        .finally(function(){
        });
    }

    getLogin(url, data,app){
        axios.post(url, data)
        .then(function(response){
            app.token = {
                headers: {'Authorization': "bearer " + response.data.token}
            };
            app.idUser = response.data.user.id;
            $('#modalLogin').modal('hide');
            alert("Login Efetuado Com sucesso");
            app.getScraps(app)
        })
        .catch(function(error){
            alert("Login incorreto");
        })
        .finally(function(){
        });
    }
    //PEGA OS CARDS DO BANCO DE DADOS
    getScraps(app, id = 0){
        let url = this.url + `/cards/${this.idUser}`;
        let idUser = {
            id_user : this.idUser
        }
        if (id == 0) {
            axios.get(url,this.token)
            .then (function(response){
                document.getElementById("row_cards").innerHTML = "";
                app.recoveryScraps(response.data);
            })
            .catch(function(error){
                console.log(error);
            })
            .finally(function(){
            });
        } else{
            let url = this.url + `/cardsId/ ${id}`;
            axios.get(url,this.token)
            .then (function(response){
                //console.log(response);
                document.getElementById("label-id").value = id;
                console.log(typeof(response.data));
                document.getElementById("edit-title").value = response.data.title
                document.getElementById("edit-content").value = response.data.content;
            })
            .catch(function(error){
                console.log(error);
            })
            .finally(function(){
            });
        };
    }

    editCard(event,id){
        let url = this.url + `/cardsId/${id}`;
        if(this.titleEdit.value && this.contentEdit.value) {
            let editedScrap ={
                title: this.titleEdit.value,
                content : this.contentEdit.value
            }
            console.log(editedScrap)
            console.log(url)
            this.updateCard(this,url,editedScrap);
        }else {
            alert("Preencha os campos!");
        };
    }

    updateCard(app,url, editedScrap){
        axios.put(url, editedScrap, this.token)
        .then (function(response){
            app.getScraps(app);
        })
        .catch(function(error){
            console.log(error);
        })
        .finally(function(){
        });
    }

    //MONTA OS CARDS PEGOS DA TABELA NA TELA
    recoveryScraps(data){
        for(item of data){
          const html =  this.cardLayout(item.title, item.content, item.id);
          this.insertHtml(html);

          document.querySelectorAll('.delete-card').forEach(item => {
            item.onclick = event => this.deleteCard(event, item.id);
        });

        document.querySelectorAll('.edit-card').forEach(item => {
            item.onclick = event => this.getScraps(this,item.id);
        });

        }
    }

    createCard(event) {
        event.preventDefault();

        const url = this.url + `/cards`
        if(this.title.value && this.content.value) {
            console.log(this.idUser);
            let scraps = {
                idUser: this.idUser,
                title: this.title.value,
                content: this.content.value
            }
            if (this.token) {
                this.createScraps( url, scraps, this);
            } else {
                this.efetuarLogin();
            }
           //location.reload();
        } else {
            alert("Preencha os campos!");
        }
    }

    createScraps(url,scraps,app){
        axios.post(url, scraps,this.token)
        .then (function(response){
            app.getScraps(app);
        })
        .catch(function (error) {
            console.log(error);
          });
    }

    deleteScraps(id,app){
        let url = this.url + `/cardsId/${id}`;
        console.log(id);
        console.log(url);
        axios.delete(url,this.token)
        .then (function(response){
            app.getScraps(app);
        })
        .catch(function (error) {
            console.log(error);
          });
    }

    cardLayout(title, content, id) {
        const html = `
            <div class="col mt-5">
                <div class="card">
                    <div class="card-body">
                    <h5 class="card-title">${title}</h5>
                    <p class="card-text">${content}</p>
                    <button type="button" class="btn btn-alert edit-card" data-toggle="modal" data-target="#modalCard"  id="${id}" data-whatever>Editar</button>
                    <button type="button" class="btn btn-danger delete-card" id="${id}">Excluir</button>
                    </div>
                </div>
            </div>
        `;
        return html;
    }

    insertHtml(html) {
        document.getElementById("row_cards").innerHTML += html;
    }

    clearForm() {
        this.title.value = "";
        this.content.value = "";
    }

    deleteCard = (event, id) => this.deleteScraps(id,this);

} 

new App();