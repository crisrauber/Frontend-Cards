# scrapbook-es6
This is a simple application to display the ES6 code. Scrapbook.

# Copy the project and setup:

## Install yarn

## Open project in your visual code

## Open the console and run command **yarn**

## After run command **yarn dev**

## Access http://localhost:8080
